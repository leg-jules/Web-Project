<template>
  <RouterView />
</template>

<style>
body {
  margin: 0 !important;
  padding: 0 !important;
  box-sizing: border-box;
}
</style>